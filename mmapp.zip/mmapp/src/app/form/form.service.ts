import { Injectable } from '@angular/core';

@Injectable()
export class FormService {
  customers;
  constructor() {
    this.init(); 
   }

   init() {
    this.customers = [
      {name: 'Google', email: 'ng@google.com'},
      {name: 'Microsoft', email: 'ts@ms.com'},
      {name: 'Ram', email: 'ram@angular.com'},
      {name: 'Raj', email: 'raj@angular.com'}
    ]
  }

  getCustomers(){
    return this.customers;
  }

  add(cname : string, cemail : string){
    let user = {
      name: cname,
      email: cemail
    }
    this.customers.push(user);
  }

}

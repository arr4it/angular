import { Component, OnInit } from '@angular/core';
import { FormService } from '../form.service';

@Component({
  selector: 'app-recent-submissions',
  templateUrl: './recent-submissions.component.html',
})
export class RecentSubmissionsComponent implements OnInit {
  customers: Array<{}>;

  constructor(formService : FormService) { 
    this.customers = formService.getCustomers();
  }

  ngOnInit() {
  }



}

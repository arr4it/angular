import { Component, OnInit } from '@angular/core';
import { FormService } from '../form.service';

@Component({
  selector: 'app-new-submission',
  templateUrl: './new-submission.component.html',
  styleUrls: []
})
export class NewSubmissionComponent implements OnInit {
  constructor(private formService : FormService) { 
  }

  ngOnInit() {
  }

  add(name, email){
    this.formService.add(name, email);
  }

}

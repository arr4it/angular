import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { AuthenticationService } from '../services/authentication.service';
import { AppService } from '../app.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  @Input() ht;

  constructor(private authentication: AuthenticationService, private appService: AppService) { }

  @Output() ctOut = new EventEmitter();
  count = 0
  onClickCount() {
     this.ctOut.emit(this.count++)
  }

  ngOnInit() {
  }

  logout() {
    this.authentication.logout(); 
    this.appService.setUserLoggedIn(false);
  }

  getUserName(){
    let uat = this.authentication.getAccessToken()
    if(uat) { this.appService.setUserLoggedIn(true); }
    return !uat ? null : uat.username;
  }


}

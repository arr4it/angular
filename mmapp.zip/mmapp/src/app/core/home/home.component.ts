import { Component, OnInit, ɵAPP_ID_RANDOM_PROVIDER } from '@angular/core';
import { UsersService } from '../users.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html'
})
export class HomeComponent implements OnInit {
  fullName = "Google Angular"
  int_pol_val = "Interpolation Works from Component!!"
  prop_val = "Property Binding Works from Component!!"

  color = 'red'

  movies = [
  {
    title: 'Abc',
    director: 'Xyz'
  },
  {
    title: 'Abc2',
    director: 'Xyz2'
  },
  {
    title: 'Abc3',
    director: 'Xyz3'
  }
]

title = 'Angular Project!'; 
todaydate = new Date(); 
jsonval = {name:'Dan', age:'25', address:{a1:'Mumbai', a2:'Karnataka'}}; 
months = ["Aug", "Sept", "Oct", "Nov", "Dec"];

userData;


  constructor(private userService : UsersService) { }

  ngOnInit(): void {
    this.userService.getData().subscribe((data) => { 
      this.userData = Array.from(Object.keys(data), k=>data[k]) 
      });
      window['appMap'] = {}
      window['appMap'].name = 'xyz';

  }

  handleInput(event){
    alert('Component recieved the value from view: ' + event.target.value);
  }

}



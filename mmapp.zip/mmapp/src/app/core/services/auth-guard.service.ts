import { Injectable } from '@angular/core';
import { AuthenticationService } from './authentication.service';
import { Router, ActivatedRouteSnapshot } from '@angular/router';

@Injectable()
export class AuthGuardService {

  constructor(private authentication: AuthenticationService, private router: Router) { }

  canActivate(route: ActivatedRouteSnapshot) {
		let token = this.authentication.getToken();

		if (!token) {
			alert("You need to login to view this page.");
			this.redirectToLoginPage();
			return false;
		}
		else if(!this.isAuthorized(route)){
			alert("you are not authorized to view this page.");
			//this.redirectToLoginPage();
			return false;
		}
		else if (this.authentication.isAuthenticated()) {
			return true;
		}
		else {
      this.authentication.refreshToken();
      return true;
		}
  }

  isAuthorized(route){
	if(route.data && route.data.roles){
		let accessToken = this.authentication.getAccessToken();
		return accessToken.roles.indexOf(route.data.roles[0]) >= 0;
	}
	return true;
  }

  //canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {}



  
  
  redirectToLoginPage() {
    this.router.navigate(['/login']);
}

}

import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

  @Injectable({
    providedIn: 'root'
  })
export class AuthenticationService {


  tokenKey: string = "user_session_token"

  constructor(private router: Router) { }

  login(username, password) {
    //send username and password to service and get token as response
    let token = this.authenticate(username, password);
    this.setToken(token);
    //this.router.navigate(['admin', 'dashboard']);
    this.router.navigate(['home']);
  }

  private authenticate(user, pwd){
    let token = {
      refresh_token: 'refreshtokencode',
      exp: new Date((new Date().getDate() +1)),
      access_token: {
        username: user,
        roles: ['RegisteredUser', (user && user === pwd) ? 'Admin' : 'GuestUser']
      }
    };
    return token
  }

  logout() {
    this.removeToken();
    this.router.navigate(['login']);
  }

  getToken() {
    return JSON.parse(sessionStorage.getItem(this.tokenKey));
  }

  setToken(token) {
    sessionStorage.setItem(this.tokenKey, JSON.stringify(token));
  }

  getAccessToken() {
    let token = sessionStorage.getItem(this.tokenKey)
    return token ? JSON.parse(token)['access_token'] : null;
  }

  isAuthenticated() {
    let token = sessionStorage.getItem(this.tokenKey);
    
    if (token) {
      return true;
    }
    else {
      return false;
    }
  }

  refreshToken() {
    //get fresh token from backend
    let token={};
    this.setToken(token);
  }

  removeToken() {
    sessionStorage.removeItem(this.tokenKey);
  }

}

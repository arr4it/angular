import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { of } from 'rxjs';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html'
})
export class AboutComponent implements OnInit {

  email; contactForm; formData
  ppval; winAppStorageData = window['appStorage'].title2;
  constructor(private route: ActivatedRoute) { 
    this.ppval = route.snapshot.paramMap.get('param1')
  } 
  ngOnInit() { 
    const myObservable = of(1, 2, 3);
    const cb = map((val: number) => val * val);
    let sqObs = cb(myObservable);

    sqObs.subscribe(
      x => console.log(x)
      
    )




    this.contactForm = new FormGroup({ 
      email: new FormControl("ng@gmail.com", Validators.compose([ Validators.required, Validators.email, Validators.pattern("[^ @]*@[^ @]*") ])), 
      skills:new FormArray([ new FormControl('java') ])
        
    }); 
    this.email = this.contactForm.get("email");
  } 

  getSkills()  {
        return this.contactForm.get("skills") as FormArray
      }

    addSkill(){
      this.getSkills().push(new FormControl(''))
     }
     
     //remove skill
     removeSkill(i){
      this.getSkills().removeAt(i);
     }
     
    
  
  onSubmit() {this.formData = this.contactForm.value; } 
  

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'app-comm';
  count;
  constructor(){
    window['appStorage'] = {}
    window['appStorage'].title2 = "WindowAppMsg"
  }
  onCount(ct){
    this.count = ct

  }
}

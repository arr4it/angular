import {Component} from '@angular/core';
import {select, Store} from '@ngrx/store';
import {Customer} from '../models/customer';
import {Observable} from 'rxjs';
import {CustomerAdd} from '../customer.actions';
@Component({
  selector: 'app-customer-add',
  templateUrl: './customer-add.component.html',
  styleUrls: ['./customer-add.component.css']
})
export class CustomerAddComponent {
  constructor(private store: Store<{ customers: Customer[] }>) {
  }

  addCustomer(customerName: string, city) {
    const customer = new Customer();
    customer.name = customerName;
    customer.city = city;
    this.store.dispatch(new CustomerAdd(customer));
  }
}

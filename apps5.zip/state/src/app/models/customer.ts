export class Customer {
  name: String = '';
  city;
}
